#include <stdio.h>

int main(int argc, char *argv[]) {

  if (argc == 1) {
		printf("There is only 1 argument");
	} else { 
		printf("There are more than 1 arguments");
	}

	return 0;
}

